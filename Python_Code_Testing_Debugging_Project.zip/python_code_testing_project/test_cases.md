# Test Cases

| Test Case | Input | Expected Result | Purpose |
|---|---|---|---|
| Addition - positive | `2, 3` | `5` | Normal input |
| Addition - negative | `-2, 3` | `1` | Boundary/negative input |
| Division - normal | `10, 2` | `5` | Normal input |
| Division - zero | `10, 0` | `ZeroDivisionError` | Exception handling |
| Even number | `8` | `True` | Normal input |
| Odd number | `7` | `False` | Alternate input |
| Valid email | `user@example.com` | `True` | Valid input |
| Missing domain | `user@example` | `False` | Invalid/edge case |

## Bugs intentionally included

1. `add()` subtracts instead of adding.
2. `validate_email()` accepts an incomplete email such as `user@example`.

The project demonstrates the workflow:

**Run code → design test cases → compare expected vs actual output → identify failures → debug → retest.**
