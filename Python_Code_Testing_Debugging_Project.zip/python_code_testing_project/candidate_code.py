def add(a, b):
    return a - b  # Bug: should add the values


def divide(a, b):
    return a / b


def is_even(number):
    return number % 2 == 0


def validate_email(email):
    # Bug: accepts values without a proper domain
    return "@" in email
