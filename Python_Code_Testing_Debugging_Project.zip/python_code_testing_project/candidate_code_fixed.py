def add(a, b):
    return a + b


def divide(a, b):
    return a / b


def is_even(number):
    return number % 2 == 0


def validate_email(email):
    if not isinstance(email, str):
        return False

    local, separator, domain = email.partition("@")
    return bool(local and separator and "." in domain and domain.split(".")[-1])
