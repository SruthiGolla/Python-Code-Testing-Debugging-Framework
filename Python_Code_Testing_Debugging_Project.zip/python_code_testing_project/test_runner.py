import importlib
import traceback
from dataclasses import dataclass
from typing import Any, Callable


@dataclass
class TestCase:
    name: str
    function: str
    args: list
    expected: Any


def run_test(module, case: TestCase):
    try:
        func: Callable = getattr(module, case.function)
        actual = func(*case.args)

        if actual == case.expected:
            return {
                "name": case.name,
                "status": "PASS",
                "expected": case.expected,
                "actual": actual,
                "error": ""
            }

        return {
            "name": case.name,
            "status": "FAIL",
            "expected": case.expected,
            "actual": actual,
            "error": "Output did not match expected result."
        }

    except Exception as exc:
        return {
            "name": case.name,
            "status": "ERROR",
            "expected": case.expected,
            "actual": "",
            "error": f"{type(exc).__name__}: {exc}"
        }


def main():
    module = importlib.import_module("candidate_code")

    test_cases = [
        TestCase("Addition - positive numbers", "add", [2, 3], 5),
        TestCase("Addition - negative number", "add", [-2, 3], 1),
        TestCase("Division - normal case", "divide", [10, 2], 5),
        TestCase("Division - zero denominator", "divide", [10, 0], "ZeroDivisionError"),
        TestCase("Even number", "is_even", [8], True),
        TestCase("Odd number", "is_even", [7], False),
        TestCase("Valid email", "validate_email", ["user@example.com"], True),
        TestCase("Invalid email - missing domain", "validate_email", ["user@example"], False),
    ]

    results = []

    for case in test_cases:
        if case.name == "Division - zero denominator":
            try:
                getattr(module, case.function)(*case.args)
                result = {
                    "name": case.name,
                    "status": "FAIL",
                    "expected": "ZeroDivisionError",
                    "actual": "No exception",
                    "error": "Expected exception was not raised."
                }
            except ZeroDivisionError:
                result = {
                    "name": case.name,
                    "status": "PASS",
                    "expected": "ZeroDivisionError",
                    "actual": "ZeroDivisionError",
                    "error": ""
                }
            except Exception as exc:
                result = {
                    "name": case.name,
                    "status": "ERROR",
                    "expected": "ZeroDivisionError",
                    "actual": type(exc).__name__,
                    "error": str(exc)
                }
        else:
            result = run_test(module, case)

        results.append(result)

    print("\nPYTHON CODE TEST REPORT")
    print("=" * 70)

    for result in results:
        print(
            f"{result['status']:5} | {result['name']} | "
            f"Expected: {result['expected']} | Actual: {result['actual']}"
        )
        if result["error"]:
            print(f"       Issue: {result['error']}")

    passed = sum(r["status"] == "PASS" for r in results)
    failed = sum(r["status"] == "FAIL" for r in results)
    errors = sum(r["status"] == "ERROR" for r in results)

    print("=" * 70)
    print(f"Total: {len(results)} | Passed: {passed} | Failed: {failed} | Errors: {errors}")


if __name__ == "__main__":
    main()
