# Python Code Testing & Debugging Framework

A beginner-friendly Python project that demonstrates software testing skills relevant to AI-generated code evaluation.

## Objective

The project runs predefined test cases against Python functions and reports:

- PASS when actual output matches the expected result
- FAIL when output is incorrect
- ERROR when unexpected exceptions occur
- Expected vs. actual values
- Basic test summary

## Skills Demonstrated

- Python programming
- Test case design
- Input/output validation
- Edge-case testing
- Exception testing
- Debugging
- Code review
- Clear test-result documentation
- Logical problem solving

## How to Run

1. Open PowerShell in this folder.
2. Run:

```powershell
python test_runner.py
```

The initial `candidate_code.py` intentionally contains two bugs. Use the test report to identify them.

After identifying the issues, replace the functions in `candidate_code.py` with the corrected implementations from `candidate_code_fixed.py`.

Run the test runner again to verify the fixes.

## Example workflow

1. Read the candidate code.
2. Identify expected behavior.
3. Create normal, invalid, and edge-case test cases.
4. Run the test runner.
5. Review failed/error cases.
6. Debug the candidate code.
7. Apply fixes.
8. Run the tests again.
9. Document the results.

## Safety

Only execute Python code that you trust. Do not use this project to run unknown or untrusted code.
